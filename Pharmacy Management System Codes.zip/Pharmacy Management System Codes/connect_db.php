<?php
$host = "localhost";
$port = "5432"; // Default PostgreSQL port
$dbname = "postgres";
$user = "postgres";
$password = "root";

// Attempt to connect to the database
$connection = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

// Check the connection
if (!is_resource($connection)) {
    die("Connection failed: " . pg_last_error());
}

// Close the connection when you're done
pg_close($connection);
?>
