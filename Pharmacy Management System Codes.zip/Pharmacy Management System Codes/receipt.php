<?php
require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');
include('connect_db.php');
session_start();
// Establish PostgreSQL connection
$host = "localhost";
$port = "5432"; // Default PostgreSQL port
$dbname = "postgres";
$user = "postgres";
$password = "root";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Connection failed: " . pg_last_error());
}
if(isset($_SESSION['username'])){
$id=$_SESSION['cashier_id'];
$fname=$_SESSION['first_name'];
$lname=$_SESSION['last_name'];
$user=$_SESSION['username'];
$t = time();
date_default_timezone_set('America/Chicago'); 
$time=date("l\, F d Y\, h:i:s A", $t);
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}
if(isset($_POST['tuma']))
{
	$pay_id=$_POST['pay_id'];
	$pType=$_POST['payment_type'];
	$amt=$_POST['amt'];
	$receiptNo=$_POST['receiptNo'];
	$cust_id=$_POST['cust_id'];
	$sql1 = pg_query($conn, "SELECT * FROM pays WHERE pay_id='$pay_id'") or die(pg_last_error());
    $result = pg_fetch_array($sql1);
     
    $sql = pg_query($conn, "INSERT INTO pays(pay_id,payment_type,amt,receiptNo,cust_id)
            VALUES('$pay_id','$pType','$amt','$receiptNo','$cust_id')");
        if ($sql > 0) {
            header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/payment.php");
        }

      $sql5 = pg_query($conn, "INSERT INTO invoice(receiptNo,served_by,date)
      		 VALUES ('$receiptNo','$id',NOW())");



      

    $sql2 = pg_query($conn,"SELECT invoice_id FROM invoice where receiptNo='$receiptNo'")or die(pg_last_error());
     $result2  = pg_fetch_array($sql2);
     $inv=$result2['invoice_id'];
    

      $sql4 = pg_query($conn,"SELECT * FROM prescription where pres_id=(select pres_id from receipts where receiptNo='$receiptNo')")or die(pg_last_error());
     $result4  = pg_fetch_array($sql4); 
     $drug_dose=$result4['dose'];
     $quant=$result4['quantity'];

$sql6 = pg_query($conn, "INSERT INTO invoice_details(invoice_id,dose,cost,quantity)
      		VALUES ('$inv', '$drug_dose', '$amt', '$quant')");

$sql3 = pg_query($conn,"SELECT * FROM invoice_details where invoice_id='{$result2['invoice_id']}'")or die(pg_last_error());
     $result3  = pg_fetch_array($sql3); 

     $sql6 = pg_query($conn,"SELECT drug_name FROM stock where stock_id='{$result4['drug_id']}'")or die(pg_last_error());
     $result6 = pg_fetch_array($sql6);

     $drug = $result6['drug_name'];
      $dose = $result3['dose']; 
    $quantity = $result3['quantity'];
    $cost = $result3['cost']; 
     
	    $file = fopen("receipts/docs/" . $receiptNo . ".txt", "a+");
    fwrite($file, $drug . ";" . $dose . ";" . $quantity . ";" . $cost . ";" . "\n");
    fclose($file);

	echo "<table width=\"100%\" border=1>";
        echo "<tr> 
		<th>Dose</th>
		<th>Quantity </th>
		<th>Cost</th></tr>";
        // loop through results of database query, displaying them in the table
		 $result = pg_query("SELECT * FROM invoice_details")or die(pg_last_error());
        while($row = pg_fetch_array($result)) 
		{
                // echo out the contents of each row into a table
                echo "<tr>";
                
			
				echo '<td>' . $row['dose'] . '</td>';
				echo '<td>' . $row['quantity'] . '</td>';
				echo '<td>' . $row['cost'] . '</td>';
				}
	


}


class MYPDF extends TCPDF {

	// Load table data from file
	public function LoadData($file) {
		// Read file lines
		$lines = file($file);
		$data = array();
		foreach($lines as $line) {
			$data[] = explode(';', chop($line));
		}
		return $data;
	}

	// Colored table
	public function ColoredTable($header,$data) {
		// Colors, line width and bold font
		$this->SetFillColor(255, 255, 255);
		$this->SetTextColor(0);
		$this->SetDrawColor(255, 255,255);
		$this->SetLineWidth(0);
		$this->SetFont('', 'B');
		// Header
		//$w = array(30,15,9,15,);
		$w = array(40,10,20,20);
		$num_headers = count($header);
		for($i = 0; $i < $num_headers; ++$i) {
			$this->Cell($w[$i], 5, $header[$i], 1, 0, 'L', 'R');
		}
		$this->Ln();
		// Color and font restoration
		$this->SetFillColor(255, 255, 255);
		$this->SetTextColor(0);
		$this->SetFont('');
		// Data
		$fill = 0;
	
		foreach($data as $row) {
			$this->Cell($w[0], 4, $row[0], 'LR', 0, 'L', $fill);
			$this->Cell($w[1], 4, number_format($row[1],2), 'LR', 0, 'R', $fill);
			$this->Cell($w[2], 4, $row[2], 'LR', 0, 'L', $fill);
			$this->Cell($w[3], 4, number_format($row[3],2), 'LR', 0, 'R', $fill);
			$this->Ln();
			$fill=!$fill;
		}
		$this->Cell(array_sum($w), 0, '', 'T');
	}
	
}


$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_INVOICE_FORMAT, true, 'UTF-8', false);


$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Pharm Management System');
$pdf->SetTitle('Receipt');
$pdf->SetSubject('Payment');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

//$pdf->SetHeaderData(PDF_RECEIPT_LOGO, PDF_RECEIPT_LOGO_WIDTH, PDF_RECEIPT_TITLE, PDF_HEADER_STRING, array(0,0,0), array(0,0,0));
//$pdf->setHeaderFont(Array(PDF_FONT_NAME_RECEIPT, '', PDF_FONT_SIZE_RECEIPT));
//$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);


$pdf->SetMargins(PDF_INVOICE_LEFT, PDF_INVOICE_TOP, PDF_INVOICE_RIGHT);
$pdf->SetHeaderMargin(PDF_INVOICE_HEADER);
$pdf->SetFooterMargin(PDF_INVOICE_FOOTER);


$pdf->SetAutoPageBreak(TRUE, PDF_INVOICE_BOTTOM);


$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);


$pdf->setLanguageArray($l);


$pdf->SetFont('times', '', 10, '', true);

$pdf->AddPage();
$spacing = -0.01;
$stretching = 75;
$pdf->setFontStretching($stretching);
				$pdf->setFontSpacing($spacing);
$titling= <<<EOD
<strong> <font style="font-size:11">Pharmacy Management System</font> </strong> <br> <strong>Official Receipt</strong><br>
Eladorado Street,<br> 2305 Bay Area Blvd, United States <br> Tel: +1 346 627 6477 <br> E-mail: pharmacygmgsys@yahoo.com 
<br>-----------------------------------------
EOD;
$header = array('Drug_Name', 'Dose', 'Qtty' , 'Cost($)');
$ddt=<<<EOD
$time   
EOD;
$html = <<<EOD

EOD;


$data = $pdf->LoadData('receipts/docs/'.$receiptNo.'.txt');
$pdf->writeHTMLCell($w=0, $h=0, $x='', $y='', $titling, $border=0, $ln=1, $fill=0, $reseth=true, $align='C', $autopadding=true);
$pdf->writeHTMLCell($w=0, $h=0, $x='', $y='', $ddt, $border=0, $ln=1, $fill=0, $reseth=true, $align='L', $autopadding=true);
$pdf->writeHTMLCell($w=0, $h=0, $x='', $y='', $html, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);

$pdf->ColoredTable($header, $data);

$pdf->SetY(-10);
		
		$pdf->Cell(0, 0, 'You were served by: '.strtoupper($user), 0, false, 'L', 0, '', 0, false, 'T', 'M');




$pdf->Output('receipts/printouts/'.$result4['customer_id'] .'-receipt.pdf','F');
unlink('receipts/docs/'.$receiptNo.'.txt');
unset($_SESSION['custId'], $_SESSION['custName'], $_SESSION['age'], $_SESSION['sex'], $_SESSION['postal_address'], $_SESSION['phone']);
header('Location: payment.php');
exit;

?>