<?php
session_start();
include_once('connect_db.php');  // Assuming this file contains the PostgreSQL connection details

// Establish PostgreSQL connection
$host = "localhost";
$port = "5432"; // Default PostgreSQL port
$dbname = "postgres";
$user = "postgres";
$password = "root";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Connection failed: " . pg_last_error());
}

if (isset($_SESSION['username'])) {
    //$id = $_SESSION['admin_id'];
    $username = $_SESSION['username'];
} else {
    header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
    exit();
}
if(isset($_SESSION['username'])){
$id=$_SESSION['pharmacist_id'];
$fname=$_SESSION['first_name'];
$lname=$_SESSION['last_name'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}
if(isset($_POST['submit']))
{
	
	$pres_id=$_POST['pres_id'];
	$drug_id=$_POST['drug_id'];
	$dose=$_POST['dose'];
	$quantity=$_POST['quantity'];
	$cust_id=$_POST['cust_id'];
	$pharmacist_id=$_POST['pharmacist_id'];


	$sql2 = pg_query($conn, "INSERT INTO prescription(pres_id,drug_id,dose,quantity,pharmacist_id,customer_id)
			VALUES('$pres_id','$drug_id','$dose','$quantity','$pharmacist_id','$cust_id')");
}
?>
<!DOCTYPE html>
<html>
<head>
<title><?php echo $user;?> -Pharmacy Management System</title>
<link rel="stylesheet" type="text/css" href="style/mystyle.css">
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" /> 
<link rel="stylesheet" href="style/table.css" type="text/css" media="screen" /> 
<script src="js/function.js" type="text/javascript"></script>
<script type="text/javascript" SRC="js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" SRC="js/superfish/hoverIntent.js"></script>
	<script type="text/javascript" SRC="js/superfish/superfish.js"></script>
	<script type="text/javascript" SRC="js/superfish/supersubs.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){ 
			$("ul.sf-menu").supersubs({ 
				minWidth:    12, 
				maxWidth:    27, 
				extraWidth:  1    
								  
			}).superfish();
							
		}); 
	</script>
	<script>
function validateForm() {
    var value = document.myform.customer_name.value;
	if(value.match(/^[a-zA-Z]+(\s{1}[a-zA-Z]+)*$/)) {
        return true;
    } else {
        alert('Name Cannot contain numbers');
        return false;
    }
}
</script>
	<script SRC="js/cufon-yui.js" type="text/javascript"></script>
	<script SRC="js/Liberation_Sans_font.js" type="text/javascript"></script>
	<script SRC="js/jquery.pngFix.pack.js"></script>
	<script type="text/javascript">
		Cufon.replace('h1,h2,h3,h4,h5,h6');
		Cufon.replace('.logo', { color: '-linear-gradient(0.5=#FFF, 0.7=#DDD)' }); 
	</script>
   <style>#left-column {height: 477px;}
 #main {height: 477px;}
</style>
</head>
<body>
<div id="content">
<div id="header" align="Center" style="background-color: #aaaaaa; border-bottom-color: #000000;">
<h1> Pharmacy Management System</h1></div>
<div id="left_column" style="background-color: #aaaaaa; border-right-color: #000000;">
<div id="button" style="background-color: #aaaaaa;">
		<ul>
			<li><a href="pharmacist.php">Dashboard</a></li>
			<li><a href="prescription.php">Prescription</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>	
</div>
</div>
<div id="main">
<div id="tabbed_box" class="tabbed_box">  
    <h4>Prescription</h4> 
<hr/>	
    <div class="tabbed_area">  
      
        <ul class="tabs">  
            <li><a href="javascript:tabSwitch('tab_1', 'content_1');" id="tab_1" class="active">View </a></li>  
            <li><a href="javascript:tabSwitch('tab_2', 'content_2');" id="tab_2">Create New </a></li>  
              
        </ul>  
          
        <div id="content_1" class="content" style="max-height: 355px; overflow-y: auto";>  
		<?php 
		/* 
		View
        Displays all data from 'Pharmacist' table
		*/
        // connect to the database
        include_once('connect_db.php');
       // get results from database
       $result = pg_query("SELECT * FROM prescription")or die(pg_last_error());
		// display data in table
        echo "<table border='1' cellpadding='5'align='center'>";
        echo "<tr> <th>Customer</th><th>Prescription N<sup>o</sup></th><th>Drug</th><th>Dosage</th><th>Quantity</th> <th>Delete</th></tr>";
        // loop through results of database query, displaying them in the table
        while($row = pg_fetch_array( $result )) {
                // echo out the contents of each row into a table
                echo "<tr>";
                echo '<td>' . $row['customer_id'] . '</td>';
                echo '<td>' . $row['pres_id'] . '</td>';
				echo '<td>' . $row['drug_id'] . '</td>';
				echo '<td>' . $row['dose'] . '</td>';
				echo '<td>' . $row['quantity'] . '</td>';
				?>
				
				<td><a href="delete_prescription.php?prescription_id=<?php echo $row['prescription_id']?>">
				<img src="images/delete-icon.jpg" width="35" height="35" border="0" /></a></td>
				<?php
		 } 
        // close table>
        echo "</table>";
?> 
        </div>  
        <div id="content_2" class="content"> 
		
		<script>
			$(document).ready(function()
	{
		$("#pres_id,#drug_id,#dose,#quantity,#pharmacist_id,#cust_id").change(function() 
		{	
			var pres_id=$("#pres_id").val();
			var drug_id=$("#drug_id").val();
			var dose=$("#dose").val();
			var quantity=$("#quantity").val();
			var pharmacist_id=$("#pharmacist_id").val();
			var cust_id=$("#cust_id").val();
			
			if(pres_id.length && drug_id.length && dose.length && quantity.length && pharmacist_id.length && cust_id.length>0 )
				{
					$.ajax(
				{  
					type: "POST", url: "check.php", data: '&pres_id='+pres_id+'&drug_id='+drug_id +'&dose='+dose +'&quantity='+quantity+'&pharmacist_id='+pharmacist_id+'&cust_id='+cust_id, success: function(msg)
					{  
						$("#viewer2").ajaxComplete(function(event, request, settings)
							{ 
								
										
									if(msg != '')
									{ 

										
										
									}  
								
									 
								   
							});
					}    
				}); 
				}
		});
		
		$("#customer_id,#customer_name,#age,#sex,#postal_address,#phone").change(function() 
		{	
			var customer_id=$("#customer_id").val();
			var customer_name=$("#customer_name").val();
			var age=$("#age").val();
			var sex=$("#sex").val();
			var postal_address=$("#postal_address").val();
			var phone=$("#phone").val();
			
			if(customer_id.length && customer_name.length && age.length && sex.length && postal_address.length && phone.length >0)
				{
					$.ajax(
				{  
					type: "POST", url: "check.php", data: 'customer_id='+customer_id +'&customer_name='+customer_name +'&age='+age +'&sex='+sex +'&postal_address='+postal_address +'&phone='+phone, success: function(msg)
					{  
						$("#viewer2").ajaxComplete(function(event, request, settings)
							{ 
								
										
									if(msg != '')
									{ 

										
										
										
										
									}  
								
									 
								   
							});
					}    
				}); 
				}
	});		
});		
		
		</script>
		<div id="viewer"><span id="viewer2"></span></div>
		<?php
		//$invNum= pg_query ("SELECT 1+MAX(invoice_id) FROM invoice");
		//$invoice=pg_fetch_array($invNum);
		//if($invoice[0]=='')
		//{$invoice_id=10; }
		//else{$invoice_id=$invoice[0];}
		//$_SESSION['invoice']=$invoice_id;
		
		?>
			<div id="table_1">
		           <!--Pharmacist-->
				   
		<form name="myform" onsubmit="return validateForm(this);" action="prescription.php" method="post" >
			<table width="200" height="106" border="0" >	
								
<tr><td align="left"><input name="pres_id" type="text" style="width:170px"  id="pres_id"placeholder="Prescription ID" /></td></tr>
				<tr><td><?php
				echo"<select  class=\"input-small\" name=\"drug_name\" style=\"width:170px\" id=\"drug_name\">";
						 $getpayType=pg_query("SELECT drug_name FROM stock");
						 echo"<option>Select Drug</option>";
		 		while($pType=pg_fetch_array($getpayType))
				{
					echo"<option>".$pType['drug_name']."</option>";
				}
		
				echo"</select>";?>  </td></tr>
				<tr><td align="left"><input name="drug_id" type="text" style="width:170px"  id="drug_id"placeholder="Drug ID" /></td></tr>
				<tr><td align="left"><input name="dose" type="text" style="width:170px" id="dose" placeholder="Dose" /></td></tr>
				<tr><td align="left"><input name="quantity" type="text" style="width:170px" id="quantity"placeholder="Quantity"/></td></tr>
				<tr><td align="left"><input name="pharmacist_id" type="text" style="width:170px"  id="pharmacist_id"placeholder="Pharmacist ID" /></td></tr>
				<tr><td align="left"><input name="cust_id" type="text" style="width:170px"  id="cust_id"placeholder="Customer ID" /></td></tr>
				<tr><td><input name="submit" type="submit" value="Submit"/></td></tr>
            </table>
		</form>
		<script>
			document.getElementById('drug_name').selectedIndex = 0;
		</script>
		</div>
		</div>  
    </div>  
</div>
</div>
<div id="footer" align="Center" style="background-color: #aaaaaa; border-top-color: #000000;"> Pharmacy Management System 2023. Copyright All Rights Reserved</div>
</div>
</body>
</html>
