<?php
session_start();
include_once('connect_db.php');
$host = "localhost";
$port = "5432"; // Default PostgreSQL port
$dbname = "postgres";
$user = "postgres";
$password = "root";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Connection failed: " . pg_last_error());
}

if(isset($_SESSION['username'])){
$id=$_SESSION['cashier_id'];
$fname=$_SESSION['first_name'];
$lname=$_SESSION['last_name'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}

if(isset($_POST['tuma']))
{
	$pres_id=$_POST['pres_id'];
	$amt=$_POST['amt'];
	$receiptNo=$_POST['receiptNo'];
     
    $sql = pg_query($conn, "INSERT INTO receipts(receiptNo,total,date,pres_id)
            VALUES('$receiptNo','$amt',NOW(),'$pres_id')");
        if ($sql > 0) {
            header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/payment.php");
        }
    }

   
?>
<!DOCTYPE html>
<html>
<head>
<title><?php echo $user;?> -  Pharmacy Management System</title>
<link rel="stylesheet" type="text/css" href="style/mystyle.css">
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" /> 
<link rel="stylesheet" href="style/table.css" type="text/css" media="screen" /> 
<script src="js/function.js" type="text/javascript"></script>
<script type="text/javascript" SRC="js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" SRC="js/superfish/hoverIntent.js"></script>
	<script type="text/javascript" SRC="js/superfish/superfish.js"></script>
	<script type="text/javascript" SRC="js/superfish/supersubs.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){ 
			$("ul.sf-menu").supersubs({ 
				minWidth:    12, 
				maxWidth:    27, 
				extraWidth:  1    
								  
			}).superfish();
							
		}); 
	</script>
	<script SRC="js/cufon-yui.js" type="text/javascript"></script>
	<script SRC="js/Liberation_Sans_font.js" type="text/javascript"></script>
	<script SRC="js/jquery.pngFix.pack.js"></script>
	<script type="text/javascript">
		Cufon.replace('h1,h2,h3,h4,h5,h6');
		Cufon.replace('.logo', { color: '-linear-gradient(0.5=#FFF, 0.7=#DDD)' }); 
	</script>
   <style>#left-column {height: 477px;}
 #main {height: 477px;}
</style>
</head>
<body>
<div id="content">
<div id="header" align="Center" style="background-color: #aaaaaa; border-bottom-color: #000000;">
<h1>Pharmacy Management System</h1></div>
<div id="left_column" style="background-color: #aaaaaa; border-right-color: #000000;">
<div id="button" style="background-color: #aaaaaa;">
		<ul>
			<li><a href="cashier.php">Dashboard</a></li>
			<li><a href="payment.php"target="_top">Process payment</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>	
</div>
</div>
<div id="main">
<div id="tabbed_box" class="tabbed_box">  
    <h4> Manage Payments</h4> 
	<hr/>	
    <div class="tabbed_area">  
      
        <ul class="tabs">  
            <li><a href="javascript:tabSwitch('tab_1', 'content_1');" id="tab_1">create Receipt</a></li>  
             <li><a href="javascript:tabSwitch('tab_2', 'content_2');" id="tab_2">Process payments</a></li> 
        </ul>  
          
        <div id="content_1" class="content"> 
        	
		  <form name="myform" onsubmit="return validateForm(validation_script.js);" action="payment.php" method="post" >
			<table width="220" height="106" border="0" >	
				
				
				<tr><td ><input name="receiptNo" type="text" style="width:170px" placeholder="ReceiptNo" required="required" id="receiptNo" /></td></tr>
				<tr><td ><input name="amt" type="text" style="width:170px" placeholder="Amount" required="required" id="amt"/></td></tr>
				<tr><td ><input name="pres_id" type="text" style="width:170px" placeholder="Prescription ID" required="required" id="pres_id" /></td></tr>
				<tr><td><input name="tuma" id="tuma" type="submit" value="Submit"/></td></tr>
            </table>
			</form>         
        </div>  
		
        <div id="content_2" class="content"> 
			<div id="table_1">
		  	<form name="myform" onsubmit="return validateForm(validation_script.js);" action="receipt.php" method="post" >
			<table width="220" height="106" border="0" >	
				<tr><td ><input name="pay_id" type="text" style="width:170px" placeholder="Payment Id" required="required" id="pay_id" /></td></tr>
				
				
								  
				
        		<tr><td><?php
        			echo "<select class=\"input-small\" name=\"payment_type\" style=\"width:170px\" id=\"payment_type\">";
        			
                      // Manually specified payment options
                      $paymentOptions = array("Credit Card", "Cash", "Debit Card");
					  echo "<option>Select Payment</option>";
        			 foreach ($paymentOptions as $option){
            			echo "<option>" . htmlspecialchars($option) . "</option>";
        			 }
				
				echo "</select>";?>  </td></tr>

				<tr><td ><input name="amt" type="text" style="width:170px" placeholder="Amount" required="required" id="amt"/></td></tr>
				<tr><td ><input name="receiptNo" type="text" style="width:170px" placeholder="ReceiptNo" required="required" id="receiptNo" /></td></tr>
				<tr><td ><input name="cust_id" type="text" style="width:170px" placeholder="Customer ID" required="required" id="cust_id" /></td></tr>
				<tr><td><input name="tuma" id="tuma" type="submit" value="Submit"/></td></tr>
            </table>
			</form>         
        	</div>  
   		 </div>  
	</div>
</div>
</div>
<div id="footer" align="Center" style="background-color: #aaaaaa; border-top-color: #000000;"> Pharmacy Management System 2023. Copyright All Rights Reserved</div>
</div>
</body>
</html>
