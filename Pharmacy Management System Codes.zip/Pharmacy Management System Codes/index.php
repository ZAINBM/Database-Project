<?php
$host = "localhost";
$port = "5432"; // Default PostgreSQL port
$dbname = "postgres";
$user = "postgres";
$password = "root";

// Attempt to connect to the database
$connection = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

// Check the connection
if (!is_resource($connection)) {
    die("Connection failed: " . pg_last_error());
}

$message="";

if(isset($_POST['submit']))
{
$username=$_POST['username'];
$password=$_POST['password'];
$position=$_POST['position'];
switch($position)
{
case 'Admin':
$query = "SELECT admin_id, username FROM admin WHERE username='$username' AND password='$password'";
$result = pg_query($connection, $query);

 if ($result) 
 {
	$row = pg_fetch_array($result);
	if ($row>0) 
	{
	session_start();
	$_SESSION['admin_id'] = $row[0];
	$_SESSION['username'] = $row[1];
	header("location:http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/admin.php");
	} 
	else {
                $message = "<font color=red>Invalid login. Try Again.</font>";
	}
 }
break;

case 'Pharmacist':
$query = "SELECT pharmacist_id, first_name, last_name, username FROM pharmacist WHERE username='$username' AND password='$password'";
$result = pg_query($connection, $query);
if ($result)
 {
	$row = pg_fetch_array($result);
	if ($row>0) 
	{
		session_start();
		$_SESSION['pharmacist_id']=$row[0];
		$_SESSION['first_name']=$row[1];
		$_SESSION['last_name']=$row[2];
		$_SESSION['username']=$row[3];
		header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/pharmacist.php");
	}
	else
	{
		$message="<font color=red>Invalid login Try Again</font>";
	}
}

break;

case 'Cashier':
$query = "SELECT cashier_id, first_name, last_name, username FROM cashier WHERE username='$username' AND password='$password'";
$result = pg_query($connection, $query);
if ($result) 
{
	$row = pg_fetch_array($result);
	if ($row>0) {
		session_start();
		$_SESSION['cashier_id']=$row[0];
		$_SESSION['first_name']=$row[1];
		$_SESSION['last_name']=$row[2];
		$_SESSION['username']=$row[3];
		header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/cashier.php");
	}
	else
	{
		$message="<font color=red>Invalid login Try Again</font>";
	}
}
break;

case 'Manager':
$query = "SELECT manager_id, first_name, last_name, username FROM manager WHERE username='$username' AND password='$password'";
$result = pg_query($connection, $query);
if ($result) 
{
	$row = pg_fetch_array($result);
	if ($row>0) {
		session_start();
		$_SESSION['manager_id']=$row[0];
		$_SESSION['first_name']=$row[1];
		$_SESSION['last_name']=$row[2];
		$_SESSION['username']=$row[3];
		header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/manager.php");
	}
	else
	{
		$message="<font color=red>Invalid login Try Again</font>";
	}
} 

break;

default:
            $message = "<font color=red>Invalid position.</font>";
            break;

}
}

echo <<<LOGIN
<!DOCTYPE html>
<html>
<head>
<title>Pharmacy Management System</title>
<link rel="stylesheet" type="text/css" href="style/mystyle_login.css">
<style>
#content {
height: auto;
}
#main{
height: auto;}
</style>
</head>
<body>
<div id="content">
<div id="header" align="Center" style="background-color: #aaaaaa; border-bottom-color: #000000;">
<h1 >Pharmacy Management System</h1>
</div>
<div id="main">

  <section class="container">
  
     <div class="login">
	 
      <h1>Login here</h1>
      $message
      <form method="post" action="index.php">
		 <p><input type="text" name="username" value="" placeholder="Username"></p>
        <p><input type="password" name="password" value="" placeholder="Password"></p>
		<p><select name="position">
		<option>--Select position--</option>
			<option>Admin</option>
			<option>Pharmacist</option>
			<option>Cashier</option>
			<option>Manager</option>
			</select></p>
        <p class="submit"><input type="submit" name="submit" value="Login"></p>
      </form>
    </div>
    </section>
</div>
<div id="footer" align="Center" style="background-color: #aaaaaa; border-top-color: #000000;"> Pharmacy Management System 2023. Copyright All Rights Reserved</div>
</div>
</body>
</html>
LOGIN;
pg_close($connection);
?>

