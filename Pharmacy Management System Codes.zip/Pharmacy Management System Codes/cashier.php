<?php
session_start();
include_once('connect_db.php');

$host = "localhost";
$port = "5432"; // Default PostgreSQL port
$dbname = "postgres";
$user = "postgres";
$password = "root";

// Attempt to connect to the database
$connection = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

// Check the connection
if (!is_resource($connection)) {
    die("Connection failed: " . pg_last_error());
}

if(isset($_SESSION['username'])){
$id=$_SESSION['cashier_id'];
$fname=$_SESSION['first_name'];
$lname=$_SESSION['last_name'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<title><?php echo $user;?> - Pharmacy Management System</title>
<link rel="stylesheet" type="text/css" href="style/mystyle.css">
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" /> 
<link rel="stylesheet" type="text/css" href="style/dashboard_styles.css"  media="screen" />
<script src="js/function.js" type="text/javascript"></script>
<style>
#left_column{
height: 470px;
}
</style>
</head>
<body>
<div id="content">
<div id="header" align="Center" style="background-color: #aaaaaa; border-bottom-color: #000000;">
<h1>Pharmacy Management System</h1></div>
<div id="left_column" style="background-color: #aaaaaa; border-right-color: #000000;">
<div id="button" style="background-color: #aaaaaa;">
<ul>
			<li><a href="cashier.php">Dashboard</a></li>
			<li><a href="payment.php"target="_top">Process payment</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>	
</div>
</div>
<div id="main">
<!-- Dashboard icons -->
            <div class="grid_7">
            	<a href="cashier.php" class="dashboard-module">
                	<img src="images/cashier_icon.jpg" width="100" height="100" alt="edit" />
                	<span>Dashboard</span>
                </a>
			     <a href="payment.php"target="_top" class="dashboard-module">
                	<img src="images/payment.png" width="100" height="100" alt="edit" />
                	<span>Process Payment</span>
                </a>
              </div>
</div>
<div id="footer" align="Center" style="background-color: #aaaaaa; border-top-color: #000000;"> Pharmacy Management System 2023. Copyright All Rights Reserved</div>
</div>
</body>
</html>
